<h1 align="center"> <a href="https://meerbiene.github.io/rcc"> Reverse CO2 Calculator </a> </h1>


<p align="center"> Takes in the amount of CO2 you saved and calculates the distance you could have travelled with different means of transport.</p>

<p align="center"> Means of transport: Plane - Domestic Flight, Plane - International Flight, Car - Petrol, Car - Diesel, Bus)</p>

<h3 align="center"> <a href="https://meerbiene.github.io/rcc"> >> check it out << </a> </h3>

<br>


<h1 align="center">  <a href="https://meerbiene.github.io/rcc"> Contributing </a> </h1>

<p align="center"> Feedback, Issues and PR's are always welcome and appreciated ❤️ </p>
